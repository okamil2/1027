import java.io.*;

public class RecursionLab {

    public static void reversePrint(String inString) {

        if (inString.length() > 0) // if string is not empty
        {
            String thePritningOutPut = "";
            while (inString.length() > 0) {

                // your code goes here
                if (inString.length() == 1) {
                    thePritningOutPut += inString.charAt(0);
                    inString = "";

                } else {
                    thePritningOutPut += inString.charAt(inString.length() - 1);
                    inString = inString.substring(0, inString.length() - 1);

                }
            }
            System.out.println(thePritningOutPut);
        }

    }

    public static String reverseString(String inString) {
        if (inString.length() > 0) {
            return inString.charAt(inString.length()-1) + reverseString(inString.substring(0, inString.length()-1));
        } else {
            return "";
        }
    }

    public static void main(String[] args) {
        String inString = "abcde";

        reversePrint(inString);        
        String revString = reverseString(inString);
        System.out.println(revString);
    }
}
