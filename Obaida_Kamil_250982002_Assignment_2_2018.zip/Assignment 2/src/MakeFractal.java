import java.util.Arrays;
import java.util.Stack;

public class MakeFractal { 
private final static int NOT_FOUND=-1;
private String alphaNumeric;
private String computedFractal;
private String initialAxion;
private Integer index,numSymbols,n,size; 
private String[] symbols;
private String[] rules;
private Integer charsPerLine=60;

// constructor 
public MakeFractal(String[] symbols,Integer numSymbols,
                   String initialAxion,String[] rules,Integer n) {
this.numSymbols=numSymbols;
this.symbols=new String[this.numSymbols];
this.rules=new String[this.numSymbols];
for(int i=0;i<this.numSymbols;i++) {
   this.symbols[i]=symbols[i];
   this.rules[i]=rules[i];
   }
this.computedFractal=initialAxion; 
this.n=n;
}

public String buildFractal() {
System.out.println("In buildFractal\n");
//print out symbols and their production rules
System.out.println("Symbol Table");
for(int i=0;i<numSymbols;i++) {
    System.out.println("symbol(" + i + ")=" + symbols[i] + 
                       "   rule(" + i +")=" + rules[i] + "\n");
}
//s is a stack

StackADT<String> s = new LinkedStack<String>();
// Runs the loop n times
for (int z = 1; z <= this.n; z++) {
// Runs the loop according to the length of the computed fractal
	for (int i = 0; i < this.computedFractal.length(); i++) {
// Breaks the computed fractal down into symbols
		String c = this.computedFractal.substring(i, i+1);
// Loop runs according to length of symbols array
		for (int j = 0; j <symbols.length; j++) {
// Compares symbol in array to symbol from computer fractal
			if (c.equals(symbols[j])) {
				s.push(rules[j]);
				break;
			}
			else if (j == (symbols.length - 1)) {
				s.push(c);
			}
		}
	}
	 this.computedFractal = "";
	while (!s.isEmpty()) {
		String remv = s.pop();
		computedFractal = remv + computedFractal; 
	} 
}

return computedFractal;
}

// Return the index of the character in symbols 
// or -1 if it is not there
public Integer in(String alphaNumeric,String[] symbols) {
for(int i=0;i<symbols.length;i++)
    {
    if(alphaNumeric.equals(symbols[i])) return(i);
    }
return(NOT_FOUND);
}

// Pretty print the computed fractal
public void prettyPrint() {
String str=computedFractal;
size=str.length();
System.out.println("\nPretty print the final fractal (60 characters per line)\n");
System.out.println("-------------------------------------------------------\n");
while(charsPerLine < size) {
    // print out substrings of str of length charsPerLine
    System.out.println(str.substring(0,charsPerLine-1));
    str=str.substring(charsPerLine,size);
    size=str.length();
} 
// print last bit of str
System.out.println(str);
}

} // MakeFractal
