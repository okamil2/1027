import java.io.*;
import java.util.Scanner;

public class ExceptionExample11 {
	   private static boolean debug = true;
   public static void main (String[] args) throws Exception {

      /* 
         - this handles the NumberFormatException

      */

      BufferedReader keyboard=
         new BufferedReader (new InputStreamReader(System.in),1);
     
      while(debug) {

      System.out.print("Enter an integer: ");
      String userTyped = keyboard.readLine();
    	  
      try {
         int value = Integer.parseInt(userTyped);
        	 debug = false;
         }
 
      catch (NumberFormatException e) {
         System.out.println("Hey, " + e.getMessage() + " is not an integer!");
      }
      }
   }

}