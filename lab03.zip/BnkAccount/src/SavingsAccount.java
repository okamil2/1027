
public class SavingsAccount extends BankAccount {

	private double interestRate;
	
	
	public SavingsAccount(double initialAmount, double rate) {
		super(initialAmount);
		interestRate = rate;
		
	}
	public void calculateInterest() {
		double monthIntRet = this.getBalance() * interestRate;
		this.deposit(monthIntRet);
	}
	public String toString(){
		String SavingsBalance = String.format("Balance: %-6f, Interest Rate: %-6f ", this.getBalance(), interestRate);
		return SavingsBalance;
	}

	public double getinterest() {
		return interestRate;
	}

}
