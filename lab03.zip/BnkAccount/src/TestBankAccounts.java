import java.io.*;

/**
 * TestBankAccounts.java:
 *  This class will test aspects of inheritance for the BankAccount class
 *  and its subclasses.
 * @author CS027b 2007
 */
// the methods of the class checking account that are overriding are deposit, withdraw and to string.

public class TestBankAccounts {
    
    public static void main(String[] args) {
      
        BankAccount bacc0 = new BankAccount(0);
        System.out.println(bacc0.toString());
        
        BankAccount bacc1 = new BankAccount(5000);
        System.out.println(bacc1.toString());
        
        CheckingAccount chacc1 = new CheckingAccount(500.0);
        System.out.println(chacc1.toString());
                          
        SavingsAccount sacc1 = new SavingsAccount(1000.0, 1.0);
        System.out.println(sacc1.toString()); 
        
        //-------------------------------------------------------
        // add your code here
        //the over riding methods are deposit, withdraw, and toString
        bacc0 = chacc1;
        //legal because we are going from parent to child
        System.out.println(bacc0.toString());
        //the checking account toString , bacc0 is associated with checkign account now.
        //chacc1 = (CheckingAccount)bacc1; doesnt work you have to write it like this instead:
        bacc1 = (BankAccount)chacc1;
        //legal because bacc1 is associated to type checking account
        BankAccount bacc2 = new CheckingAccount(200.0);
        chacc1 = (CheckingAccount)bacc2;
        //legal because bacc2 is associated with checking account object
        //bacc1.deductFees() wont work because bacc1 is a bank account
        chacc1.deductFees();
        //Works because chacc1 points to bacc1 which was casted to type checking account
        //sacc1.deductFees(); wont work because acc1 is of type savings account
        chacc1.deposit(100.0); 
        
        //stack overflow error occurred because of the super deposit method. This is because
        //when calling a deposit method within itself and their is a loop their wont be an end to the loop
    }
    
}
