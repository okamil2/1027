/**
 * Phone class represents a phone listing
 * 
 * @author CS1027 for Lab
 */

public class Phone implements Comparable<Phone> {

	private String name;
	private String phone;

	public Phone() {
		name = "";
		phone = "";
	}

	public Phone(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String toString() {
		return (name + " " + phone);
	}

	public void toString2(ArrayIterator returnedList1) {
		while (returnedList1.hasNext()) {
			Phone test = (Phone) returnedList1.next();
			System.out.println(test.getName() + " " + getPhone());
		}
	}

	public boolean equals(Phone other) {
		return (name == other.name) && (phone == other.phone);

	}

	public int compareTo(Phone obj) {
		// return this.name.compareTo(obj.getName()); // sort by name
		return this.phone.compareTo(obj.getPhone()); // sort by phone
		/**
		 * int result = 0;
		 * 
		 * if (this.name.equals(obj)) { result = 0; } else { for (int i = 0; i <
		 * this.name.length(); i++) { char c = this.name.charAt(i); char t =
		 * ((obj.getName()).charAt(i)); if (Character.getNumericValue(c) >
		 * Character.getNumericValue(t)) { result = 1; break; } else if
		 * (Character.getNumericValue(c) < Character.getNumericValue(t)) { result = -1;
		 * break; } } }
		 * 
		 * return result;
		 **/
	}
}