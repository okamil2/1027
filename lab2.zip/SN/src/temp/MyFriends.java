package temp;
public class MyFriends {
  public static void main(String args[]) {

    SocialNetwork contacts = new SocialNetwork();

    contacts.add("Snoopy","Dog","snoopy@uwo.ca");
    contacts.add("Felix","Cat","felix@uwo.ca");
    contacts.add("Mickey","Mouse","mickey@uwo.ca");

    System.out.println(contacts.toString());
    System.out.println("I have " + contacts.getNumFriends() + " friends in my list.");
    
    if (contacts.remove("Snoopy","Dog") == true) {
    	System.out.println("Snoop Dog was removed successfully");
    }
    else {
    	System.out.println("Snoop Dog was not removed Successfully");
    }
    if (contacts.remove("Spy","Dog") == true) {
    	System.out.println("Spy Dog was removed successfully");
    }
    else {
    	System.out.println("Spy Dog was not removed Successfully");
    }
  }
  
}
