///////////////////////////////////////////////////////////////////
//   Obaida Kamil, 250982002                                      //
//   okamil2@uwo.ca                           					 //
//   Assignment 1, CS1027, 2018                                  //
///////////////////////////////////////////////////////////////////


public class Continent {
	String countryName;
	String continentName;

// just declaring the arguments for the Continent as strings 
public Continent(String countryName, String continentName) {
	this.countryName = countryName;
	this.continentName = continentName;
}	
/**
 below is just a bunch of getters and setters for the methods that we need to build our program.
 These methods are needed because with them we declare what kind of variables are (integers, doubles or strings)
 and others are to set the methods for future use so we can change things.
 
 
  */
public String getCountryName() {
	return countryName;
}

public String getContinentName() {
	return continentName;
}

public void setCountryName(String newCountry) {
	this.countryName = newCountry;
}

public void setContinentName(String newContinent) {
	this.continentName = newContinent;
}
// the to string method that we have below is used to return the name of the continent that the country is in.
public String toString() {
String SecondToString = String.format("The name of the country is: %-20s \n", this.getCountryName()) +
String.format("The name of the continent it's in is: %-20s \n" , this.getContinentName());

return SecondToString;
}
}