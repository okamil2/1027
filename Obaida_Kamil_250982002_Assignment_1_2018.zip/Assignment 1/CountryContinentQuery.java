///////////////////////////////////////////////////////////////////
//   Obaida Kamil, 250982002                                      //
//   okamil2@uwo.ca                           					 //
//   Assignment 1, CS1027, 2018                                  //
///////////////////////////////////////////////////////////////////

// Again, below we are declaring the variables for the method CountryContinentQuety so we can use them later on.
// we made them private to avoid them being overridden from other classes.
public class CountryContinentQuery {
	private String countryName;
	private String continentName;
	private int countryPopulation;
	private int countryArea;
	private int countryCt=0;
	private int continentCt=0;
	private int defualtSize = 30;
	Country[] countryArray = new Country[defualtSize];
	Continent[] continentArray = new Continent[defualtSize];
// we clone the countryarray and the continentarray so we can manipulate them later on in our code
public CountryContinentQuery(Country[] countryArray, Continent[] continentArray, int Ct) {
	this.countryArray=countryArray.clone();
	this.continentArray=continentArray.clone();
	this.continentCt = Ct;
	this.countryCt= Ct;
}
// we are getting the country names in each continent with the method below, we have if statements in case we didnt find any
public String getCountriesOnContinent(String continentName) {
		String countriesCont = "";
		String noCounts = "No countries were found";
		for (int i=0; i<continentCt; i++) {
			if (continentArray[i].getContinentName().equals(continentName)) {
				countriesCont = countriesCont + String.format("%-5s,", continentArray[i].getCountryName());
			}
		}
		if (countriesCont == "") {
			return noCounts;
		
		}else {
			return countriesCont;	
		}
}
// this method is sort of similar to the one above, we are getting the countries names again but this time after we do that 
//we add a bit more code to get the population too.
public String getPopulationOfContinent(String continentName) {
	String countPops = "";
	String noRes = "No results for population were found";
	for(int i=0; i < continentCt; i++) {
		if (continentArray[i].getContinentName().equals(continentName)) {
			int index = 0;
			boolean found = false;
			while (index < countryCt && !found) {
				if(continentArray[i].getCountryName().equals(countryArray[index].getName())) {
					found = true;
					countPops = countPops + String.format("%-5s: %-5d \n", continentArray[i].getCountryName(), countryArray[index].getPopulation());
				
				}else {
					index++;	
				}		
			}
		}
	}
	if (countPops == ""){
		return noRes;
	
	}else {	
		return countPops;
	}
	
	
}
// the to string here is to get the country's name, location meaning in which continent, population adn finally the area.
public String toString() {
	String toStringString = "";
	String noRes = "No results were found";
	for (int i=0; i<continentCt; i++) {
		for(int x=0; x<continentCt; x++) {
			if(continentArray[i].getCountryName().equals(countryArray[x].getName())) {
				toStringString = toStringString + String.format("Country Name: %-3s, Located in: %-3s, Population: %-3d, Area: %-3d \n" , countryArray[x].getName(), continentArray[i].getContinentName(), countryArray[x].getPopulation(), countryArray[x].getArea());
			}
			
		}
	}
	if (toStringString == "") {
		return noRes;
	
	}else {
		return toStringString;
		
	}


}


}