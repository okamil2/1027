///////////////////////////////////////////////////////////////////
//Obaida Kamil, 250982002                                      //
//okamil2@uwo.ca                           					 //
//Assignment 1, CS1027, 2018                                  //
///////////////////////////////////////////////////////////////////



public class Country {
	
	String name;
	int population;
	int area;


public Country(String name, int population, int area) {
	this.name = name;
	this.population = population;
	this.area = area;
	
	
}

public String getName() {
	return name;
}
public int getPopulation() {
	return population;
}
public int getArea() {
	return area;
}
// this method below, getPopulationDensity, we are using to return the density of countries. We divide the population by area.
public double getPopulationDensity() {
	double popDensity = population/area;
	return popDensity;
}
public void setPopulation(int newPopulation) {
	this.population =  newPopulation;
}
public void setArea(int newArea) {
	this.area = newArea;
}
/**
 The to string method below is to return the country's name, its population, area and finally the density. 
 */
public String toString() {
String FirstToString= String.format("This country's name is: %-20s \n", this.getName()) +
String.format("The country's population is: %-10d \n", this.getPopulation()) +
String.format("The country's area is: %-10d \n" ,this.getArea()) +
String.format("The country's population density is: %.2f \n", this.getPopulationDensity());
return FirstToString;
}
}